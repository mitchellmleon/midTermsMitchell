/*
let myAnimals = ["dog", "cat", "horse", "meerkat"]

let addAnimal = prompt("Enter a new animal to add to the array")

let newAnimal = addAnimal.toLowerCase()

myAnimals.push(newAnimal)

console.log(`The last animal is ${myAnimals[myAnimals.length - 1]}`)

console.log(myAnimals)
*\