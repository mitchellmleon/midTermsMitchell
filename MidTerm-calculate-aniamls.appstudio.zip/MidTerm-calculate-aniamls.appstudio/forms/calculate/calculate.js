/*
function calcAvgSquare (a, b, c){

return (((a + b + c)/3) * (a**2))

}

let num1 = Number(prompt("Enter your first number"))

let num2 = Number(prompt("Enter your second number"))

let num3 = Number(prompt("Enter your third number"))

let calcAvgSquareAnswer = calcAvgSquare(num1, num2, num3) 

alert(`The answer is ${calcAvgSquareAnswer}.`)

*\