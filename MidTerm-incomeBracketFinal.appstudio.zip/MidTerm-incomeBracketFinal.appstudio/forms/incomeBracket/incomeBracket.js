/*

btnSubmit.onclick=function(){

let income = Number(inptIncome.value)

let bracket = `With your income of $${income}, you are in a tax bracket of `

if (income < 30000) {

lblResult.value = `${bracket} 8%.`

} else if (income < 99999 && income >= 30000) {

lblResult.value = `${bracket} 15%.`

} else if (income >= 99999) {

lblResult.value = `${bracket} 25%.`

}

}

btnGoAgain.onclick=function(){

lblResult.value = "Enter a new income"

}
*/